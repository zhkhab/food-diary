prompt --application/shared_components/user_interface/lovs/1
begin
--   Manifest
--     1
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>2200391555451690
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DEV'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(5000745027220750)
,p_lov_name=>'1'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'FOOD_JOURNAL'
,p_return_column_name=>'FJ_ID'
,p_display_column_name=>'MEAL_DATE'
,p_default_sort_column_name=>'MEAL_DATE'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
