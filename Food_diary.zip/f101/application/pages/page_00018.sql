prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>2200391555451690
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DEV'
);
wwv_flow_api.create_page(
 p_id=>18
,p_user_interface_id=>wwv_flow_api.id(3993066449269626)
,p_name=>'Analytics'
,p_alias=>'REPORTS_PAGE'
,p_step_title=>'Reports'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_browser_cache=>'N'
,p_last_updated_by=>'DEV'
,p_last_upd_yyyymmddhh24miss=>'20220413014206'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8601972886133923)
,p_plug_name=>'Meal log'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(3913754355269471)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with p as (',
'           select pers_id,',
'                  full_name,',
'                  dob,',
'                  person_pkg.get_pers_info(pers_id) pers_info',
'             from person',
'            where pers_id=:CURRENT_PERSON',
'                  )',
'select ml.ml_id,',
'       ml.ml_date,',
'       ml.ml_time,',
'       ml.ml_datetime,',
'       ml.meal_id,',
'       m.meal_name,',
'       m.is_homemade,',
'       ml.srvng_size sz_id,',
'       sz.srvng_size,',
'       sz.srvng_factor,',
'       sz.srvng_code,',
'       ml.person_id,',
'       p.full_name,',
'       p.dob,',
'       p.pers_info',
'  from meal_log ml,',
'       meal m,',
'       p,',
'       serving_size sz',
' where ml.meal_id=m.meal_id',
'   and ml.srvng_size=sz.sz_id',
'   and ml.person_id=p.pers_id;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(8602041825133924)
,p_region_id=>wwv_flow_api.id(8601972886133923)
,p_chart_type=>'line'
,p_title=>'MEALS'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(8602186871133925)
,p_chart_id=>wwv_flow_api.id(8602041825133924)
,p_seq=>10
,p_name=>'Meal log'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'MEAL_ID'
,p_items_label_column_name=>'MEAL_NAME'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(8731938084771523)
,p_chart_id=>wwv_flow_api.id(8602041825133924)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_api.create_jet_chart_axis(
 p_id=>wwv_flow_api.id(8732038107771524)
,p_chart_id=>wwv_flow_api.id(8602041825133924)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8602518754133929)
,p_plug_name=>'Food log'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(3904225413269464)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>5
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with p as (',
'           select pers_id,',
'                  full_name,',
'                  dob,',
'                  person_pkg.get_pers_info(pers_id) pers_info',
'             from person',
'            where pers_id=:CURRENT_PERSON',
'                  )',
'select fl.fl_id,',
'       fl.ml_id,',
'       ml.ml_datetime,',
'       ml.ml_date,',
'       ml.ml_time,',
'       fl.meal_id,',
'       m.meal_name,',
'       m.is_homemade,',
'       fl.food_id,',
'       f.food_name,',
'       ft.type_id,',
'       ft.type_name,',
'       ft.parent_id,',
'       fl.amount,',
'       fl.unit_id,',
'       u.unit_name,',
'       u.parent_id parent_unit,',
'       u.factor',
'  from food_log fl,',
'       food f,',
'       food_type ft,',
'       meal_log ml,',
'       meal m,',
'       p,',
'       unit u',
' where fl.ml_id=ml.ml_id',
'   and fl.meal_id=m.meal_id',
'   and fl.food_id=f.food_id',
'   and f.food_type=ft.type_id(+)',
'   and fl.unit_id=u.unit_id',
'   and ml.person_id=p.pers_id;'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(8602686774133930)
,p_region_id=>wwv_flow_api.id(8602518754133929)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(8602739598133931)
,p_chart_id=>wwv_flow_api.id(8602686774133930)
,p_seq=>10
,p_name=>'Meal log'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'FL_ID'
,p_items_label_column_name=>'FOOD_NAME'
,p_aggregate_function=>'COUNT'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_api.component_end;
end;
/
