prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>2200391555451690
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DEV'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(3993066449269626)
,p_name=>'Edit meallog'
,p_alias=>'EDIT_MEALLOG_PAGE'
,p_page_mode=>'MODAL'
,p_step_title=>'Edit meal log'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_browser_cache=>'N'
,p_last_updated_by=>'DEV'
,p_last_upd_yyyymmddhh24miss=>'20220409222234'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7045818766842715)
,p_plug_name=>'Edit meallog'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(3865928930269423)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7024524486250321)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7045818766842715)
,p_button_name=>'UPDATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3968334181269557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save'
,p_button_position=>'BOTTOM'
,p_confirm_message=>'Do you want to save your changes?'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7549945903519745)
,p_branch_name=>'Close dialog'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:6::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(7024524486250321)
,p_branch_sequence=>10
,p_branch_condition_type=>'ITEM_IS_NOT_NULL'
,p_branch_condition=>'ML_ID'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7023845139250314)
,p_name=>'ML_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(7045818766842715)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7023937986250315)
,p_name=>'ML_DATE'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(7045818766842715)
,p_prompt=>'Date'
,p_format_mask=>'YYYY-MM-DD'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>11
,p_cMaxlength=>11
,p_field_template=>wwv_flow_api.id(3967125427269553)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'NATIVE'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7024027850250316)
,p_name=>'ML_TIME'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(7045818766842715)
,p_prompt=>'Time'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>5
,p_cMaxlength=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(3967125427269553)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'TRAILING'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7024265250250318)
,p_name=>'ML_AMOUNT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(7045818766842715)
,p_prompt=>'Amount'
,p_source=>'ML_AMOUNT'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sz.srvng_size,',
'       sz.sz_id',
'  from serving_size sz,',
'       meal$serving_size msz',
' where msz.sz_id=sz.sz_id',
'   and msz.meal_id=:ML_MEAL_ID;'))
,p_lov_cascade_parent_items=>'ML_MEAL_ID'
,p_ajax_items_to_submit=>'ML_MEAL_ID'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>10
,p_cMaxlength=>10
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_api.id(3967125427269553)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7025073217250326)
,p_name=>'ML_PERSONID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(7045818766842715)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7025153720250327)
,p_name=>'ML_MEAL_ID'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(7045818766842715)
,p_prompt=>'Meal/drink'
,p_source=>'ML_MEAL_ID'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select meal_name,',
'       meal_id',
'  from meal',
' order by meal_id;'))
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(3967125427269553)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8169788671084503)
,p_name=>'ML_COMMENT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(7045818766842715)
,p_prompt=>'Comment'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(3965854674269550)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'TRAILING'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7024736820250323)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Display object'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ml.ml_date,',
'       ml.ml_time,',
'       ml.meal_id,',
'       ml.srvng_size,',
'       ml.person_id,',
'       ml.comment_',
' into :ML_DATE,',
'      :ML_TIME,',
'      :ML_MEAL_ID,',
'      :ML_AMOUNT,',
'      :ML_PERSONID,',
'      :ML_COMMENT',
' from meal_log ml',
'where ml.ml_id=:ML_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'ML_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7549283748519738)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update object'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'meal_pkg.meallog_save(ml_id       =>:ML_ID,',
'                      ml_date     =>:ML_DATE,',
'                      ml_time     =>:ML_TIME,',
'                      ml_datetime =>to_date(:ML_DATE||'' ''||:ML_TIME, ''yyyy-mm-dd hh24:mi''),',
'                      meal_id     =>:ML_MEAL_ID,',
'                      srvng_size  =>:ML_AMOUNT,',
'                      person_id   =>:ML_PERSONID,',
'                      comment_    =>:ML_COMMENT',
'                      ); '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(7024524486250321)
,p_process_when=>'ML_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.component_end;
end;
/
