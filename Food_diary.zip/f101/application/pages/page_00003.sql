prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>2200391555451690
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DEV'
);
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>wwv_flow_api.id(3993066449269626)
,p_name=>'Create person'
,p_alias=>'CREATE_PERSON_PAGE'
,p_page_mode=>'MODAL'
,p_step_title=>'Create person'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_browser_cache=>'N'
,p_last_updated_by=>'DEV'
,p_last_upd_yyyymmddhh24miss=>'20220410011536'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6935938438591185)
,p_plug_name=>'Create person'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(3865928930269423)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6930760208578406)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6935938438591185)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3968334181269557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BOTTOM'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(6931261779578411)
,p_branch_name=>'Return to previous page'
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:3,2:PERSON:&PERS_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6930336070578402)
,p_name=>'LASTNAME'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(6935938438591185)
,p_prompt=>'Last name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>100
,p_cMaxlength=>100
,p_field_template=>wwv_flow_api.id(3967125427269553)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'TRAILING'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6930424395578403)
,p_name=>'FIRSTNAME'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(6935938438591185)
,p_prompt=>'First name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>100
,p_cMaxlength=>100
,p_field_template=>wwv_flow_api.id(3967125427269553)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'TRAILING'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6930509604578404)
,p_name=>'MIDDLENAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(6935938438591185)
,p_prompt=>'Middle name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>100
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(3965854674269550)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'TRAILING'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6930611442578405)
,p_name=>'DOB'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(6935938438591185)
,p_prompt=>'Date of birth'
,p_format_mask=>'YYYY-MM-DD'
,p_display_as=>'NATIVE_DATE_PICKER_JET'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(3967125427269553)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'NATIVE'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_11=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8600371298133907)
,p_name=>'PERS_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(6935938438591185)
,p_use_cache_before_default=>'NO'
,p_source=>'PERS_ID'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6930929667578408)
,p_name=>'Insert person'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(6930760208578406)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6931095722578409)
,p_event_id=>wwv_flow_api.id(6930929667578408)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' -- vPerson person.pers_id%type;',
'begin',
'  person_pkg.person_save(pers_id     =>:PERS_ID,',
'                         first_name  =>:FIRSTNAME,',
'                         last_name   =>:LASTNAME,',
'                         middle_name =>:MIDDLENAME,',
'                         dob         =>to_date(:DOB, ''yyyy-mm-dd'')',
'                         );',
'  --apex_util.set_session_state(''CURRENT_PERSON'', vPerson);',
'end;'))
,p_attribute_02=>'FIRSTNAME,MIDDLENAME,LASTNAME,DOB,PERS_ID'
,p_attribute_03=>'PERS_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8600499960133908)
,p_event_id=>wwv_flow_api.id(6930929667578408)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'PERS_ID'
);
wwv_flow_api.component_end;
end;
/
