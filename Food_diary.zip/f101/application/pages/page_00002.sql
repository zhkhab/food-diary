prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>2200391555451690
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'DEV'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(3993066449269626)
,p_name=>'Current person'
,p_alias=>'CURRENT_PERSON_PAGE'
,p_page_mode=>'MODAL'
,p_step_title=>'Current person'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_browser_cache=>'N'
,p_last_updated_by=>'DEV'
,p_last_upd_yyyymmddhh24miss=>'20220410010751'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6902248516640789)
,p_plug_name=>'Person'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_api.id(3865928930269423)
,p_plug_display_sequence=>20
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6930234303578401)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6902248516640789)
,p_button_name=>'CREATE_PERSON'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_api.id(3968334181269557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create person'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3,2,1::'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6840109402977831)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(6902248516640789)
,p_button_name=>'ENTER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3968334181269557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enter'
,p_button_position=>'BOTTOM'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(6931750650578416)
,p_branch_name=>'No person returned'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:2,1:CURRENT_PERSON:&PERSON.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_api.id(6840109402977831)
,p_branch_sequence=>10
,p_branch_condition_type=>'ITEM_IS_NOT_NULL'
,p_branch_condition=>'PERSON'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6840067147977830)
,p_name=>'PERSON'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6902248516640789)
,p_prompt=>'Choose person'
,p_source=>'PERSON'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select person_pkg.get_pers_info(pers_id),',
'       pers_id',
'  from person',
' order by pers_id;'))
,p_cSize=>30
,p_cMaxlength=>100
,p_field_template=>wwv_flow_api.id(3967125427269553)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_api.component_end;
end;
/
